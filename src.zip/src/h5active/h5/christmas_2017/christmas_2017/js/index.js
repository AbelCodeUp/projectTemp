// var ajaxUrl = 'http://117.107.153.228:808/api/Christmas/';
var ajaxUrl = 'http://learnapi.gogo-talk.com/api/Christmas/';
// var local = 'http://wx.gogo-talk.com/h5test/aaa/';
var access_code;
var openId;
$(function() {

    /*音乐*/
    document.addEventListener("WeixinJSBridgeReady",  function ()  {
        page1_btu_succ();
    },  false);
    //解决安卓手机软件盘问题
    $('.page1').height($(window).height());
    $.getScript('http://res.wx.qq.com/open/js/jweixin-1.0.0.js', function(response, status) {
        var appId;
        var timestamp;
        var nonceStr;
        var sign;
        $.get("http://hfapi.gogo-talk.com/api/Share/ShareByWebChat", {
            url: location.href
        }, function(data) {
            if (data != "") {
                data = data.data;
                appId = data.appId;
                timestamp = data.timeStamp;
                nonceStr = data.nonceStr;
                sign = data.sign;
                wx.config({
                    debug: false,
                    appId: appId,
                    timestamp: timestamp,
                    nonceStr: nonceStr,
                    signature: sign,
                    jsApiList: [
                        'checkJsApi',
                        'onMenuShareTimeline',
                        'onMenuShareAppMessage'
                    ]
                });
                wx.ready(function() {
                    var shareData = {
                        title: 'GoGoTalk双旦享好礼，玩转迪士尼！100%中奖！',
                        desc: '快来开启你的双旦礼物吧',
                        link: 'http://wx.gogo-talk.com/h5active/h5/christmas_2017/index.html',
                        imgUrl: 'http://o2mzy.gogo-talk.com/active/christmas_2017/fenxiang.jpg'
                    };
                    wx.onMenuShareAppMessage(shareData);
                    wx.onMenuShareTimeline(shareData);
                });
                wx.error(function(res) {
                    //alert(res.errMsg);
                });
            }
        });
    });
    //服务器时间
    jQuery.ajax({
        type: 'GET',
        url: ajaxUrl + "GetServerDate",
        dataType: "json",
        success: function(res) {
            var nowtime = res.data.timestamp; //此处须获取服务器时间
            var starttime = res.data.ChristmasCanOpenBoxTimeStamp; //此处须获取活动开始时间
            var time = starttime - nowtime;
            //倒计时
            if (time > 0) {
                $('.tancheng_lingjiang_bg').hide();
                $('.tancheng_jiang_bg').hide();
                $('.tancheng_daojishi_bg').show();
                var setT = setInterval(function() {
                    time = time - 1;
                    if (time > 0) {
                        var day = parseInt(time / 60 / 60 / 24);
                        var hour = parseInt(time / 60 / 60 % 24);
                        var minute = parseInt(time / 60 % 60);
                        var seconds = parseInt(time % 60);
                        if (day < 10) {
                            day = '0' + day;
                        }
                        if (hour < 10) {
                            hour = '0' + hour;
                        }
                        if (minute < 10) {
                            minute = '0' + minute;
                        }
                        if (seconds < 10) {
                            seconds = '0' + seconds;
                        }
                        $('.tancheng_daojishi_rel_p').eq(0).html(day);
                        $('.tancheng_daojishi_rel_p').eq(2).html(hour);
                        $('.tancheng_daojishi_rel_p').eq(4).html(minute);
                        $('.tancheng_daojishi_rel_p').eq(6).html(seconds);
                    } else {
                        //倒计时结束，可以领奖弹层
                        clearInterval(setT);
                        $('.tancheng_daojishi_rel_p').eq(0).html('00');
                        $('.tancheng_daojishi_rel_p').eq(2).html('00');
                        $('.tancheng_daojishi_rel_p').eq(4).html('00');
                        $('.tancheng_daojishi_rel_p').eq(6).html('00');
                        $('.tancheng_daojishi_bg').hide();
                        $('.tancheng_jiang_bg').hide();
                        $('.tancheng_lingjiang_bg').show();
                    }
                }, 1000);
            }
        }
    });


    function GetQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
    }

    access_code = GetQueryString('code');
    openId = localStorage.getItem('OpenId');
    if (access_code == null) {
        var url = "https://open.weixin.qq.com/connect/oauth2/authorize";
        url += "?appid=wxfc9793b7b7f4a417&redirect_uri=" + encodeURIComponent(location.href) + "&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect";
        location.href = url;
    }
    if (access_code != null) {

        access_code = GetQueryString('code');
        if (openId == null) {
            jQuery.ajax({
                type: 'GET',
                url: ajaxUrl + "ChristmasGetUserStatusByCode?Code=" + access_code,
                dataType: "json",
                success: function(res) {
                    //alert(res.result);

                    openId = res.OpenId;
                    if (res.result >= 1) {

                        localStorage.setItem('OpenId', res.OpenId);
                    }

                    if (res.result == -101) {
                        $('.page1').show();
                        $(".page2").hide();
                        $(".tanceng").hide();
                    } else {
                        $('.page1').hide();
                        if (res.result == 1) {
                            part11();
                        } else if (res.result == 2) {
                            part2();
                        } else if (res.result == 3) {
                            part3();
                        } else if (res.result == 4) {
                            part4();
                        } else if (res.result == 5) {
                            part5(res);
                        } else if (res.result == -1) {
                            $(".tishi span").html('活动已结束');
                            $(".tishi").show();
                            if (res.box.AwardID > 0) {
                                part5(res);
                            } else {
                                $(".page1").show();
                                $('.page1_form_but').attr('onclick', '');
                                $('.page2_box').attr('onclick', '');
                                $('.page2_yu').attr('onclick', '');
                            }

                        } else {
                            $.tishi(res.msg);
                            $('.page1_form_but').attr('onclick', 'form_sub();');
                            $('.page2_box').attr('onclick', 'lingjiang();');
                            $('.page2_yu').attr('onclick', "popup_open('.shuoming_tanceng');popup_close('.page2_yu');");
                        }
                    }

                }
            });
        } else {
            jQuery.ajax({
                type: 'GET',
                url: ajaxUrl + "ChristmasGetUserStatusByOpenId?Openid=" + openId,
                dataType: "json",
                success: function(res) {
                    //alert(res.result);

                    // openId=res.OpenId;
                    // localStorage.setItem('OpenId3',res.OpenId);
                    if (res.result == -101) {
                        $('.page1').show();
                        $(".page2").hide();
                        $(".tanceng").hide();
                    } else {
                        $('.page1').hide();
                        if (res.result == 1) {
                            part11();
                        } else if (res.result == 2) {
                            part2();
                        } else if (res.result == 3) {
                            part3();
                        } else if (res.result == 4) {
                            part4();
                        } else if (res.result == 5) {
                            part5(res);
                        } else if (res.result == -1) {
                            $(".tishi span").html('活动已结束');
                            $(".tishi").show();
                            if (res.box.AwardID > 0) {
                                part5(res);
                            } else {
                                $(".page1").show();
                                $('.page1_form_but').attr('onclick', '');
                                $('.page2_box').attr('onclick', '');
                                $('.page2_yu').attr('onclick', '');
                            }

                        } else {
                            $.tishi(res.msg);
                            $('.page1_form_but').attr('onclick', 'form_sub();');
                            $('.page2_box').attr('onclick', 'lingjiang();');
                            $('.page2_yu').attr('onclick', "popup_open('.shuoming_tanceng');popup_close('.page2_yu');");
                        }
                    }

                }
            });
        }
    }



});

/* 音乐 */
function music_load() {
    if ($(".music_num").attr("num") == "1") {
        $(".music_num").attr("num", "2");
        $(".music_open").css("display", "none");
        $(".music_close").css("display", "block");
        document.getElementById("aud").pause();
    } else {
        $(".music_num").attr("num", "1");
        $(".music_open").css("display", "block");
        $(".music_close").css("display", "none");
        document.getElementById("aud").play();
    }
}
/* iphone音乐播放 提交成功时调用*/
function page1_btu_succ() {
    $(".music_num").attr("num", "1");
    $(".music_open").css("display", "block");
    $(".music_close").css("display", "none");
    document.getElementById("aud").play();
}
/*提示*/
jQuery.tishi = function(e) {
    $(".tishi span").html(e);
    $(".tishi").show();
    setTimeout(function() {
        $(".tishi").hide();
    }, 1800)
};

/*打开弹窗*/
function popup_open(e) {
    $(e).show();
}
/*关闭弹窗*/
function popup_close(e) {
    $(e).hide();
}



function part1() {
    //正常登陆 （没选盒子）
    /*离开动画*/
    $(".page1_form_box").addClass("page1_form_box2");
    /*进入第二页*/
    setTimeout(function() {
        $(".page2").show();
    }, 1600);
}

function part11() {
    //正常登陆 （没选盒子）
    /*离开动画*/
    $(".page1").hide();
    /*进入第二页*/
    $(".page2").show();
}

function part2() {
    //已选盒子（未到开奖时间）
    /*离开动画*/
    $(".page1").hide();
    /*进入第二页*/
    $(".page2").show();
    $('.shuoming_tanceng').hide();
    $('.page2_box').attr('onclick', '');
    $('.page2_yu').attr('onclick', '');
    $('.tancheng_lingjiang_bg').hide();
    $('.tancheng_jiang_bg').hide();
    $('.tancheng_daojishi_bg').show();
    $('.tanceng').show();
}

function part3() {
    // 已选盒子（超过开奖时间）
    /*离开动画*/
    $(".page1").hide();
    /*进入第二页*/
    $(".page2").show();
    $('.shuoming_tanceng').hide();
    $('.page2_box').attr('onclick', '');
    $('.page2_yu').attr('onclick', '');

    $('.tancheng_lingjiang_box').attr('onclick', '$.tishi("已超过开奖时间");');
    $('.tancheng_lingjiang_but').attr('onclick', '$.tishi("已超过开奖时间");');
    $('.tancheng_daojishi_bg').hide();
    $('.tancheng_lingjiang_bg').show();
    $('.tancheng_jiang_bg').hide();
    $('.tanceng').show();
}

function part4() {
    // 已选盒子（符合开奖时间,未抽奖）
    /*离开动画*/
    $(".page1").hide();
    /*进入第二页*/
    $(".page2").show();
    $('.shuoming_tanceng').hide();
    $('.page2_box').attr('onclick', '');
    $('.page2_yu').attr('onclick', '');

    $('.tancheng_lingjiang_bg').show();
    $('.tancheng_jiang_bg').hide();
    $('.tancheng_daojishi_bg').hide();
    $('.tanceng').show();
}

function part5(res) {
    // 已选盒子（已抽奖）
    /*离开动画*/
    $(".page1").hide();
    $(".page2").show();
    $('.shuoming_tanceng').hide();
    $('.page2_box').attr('onclick', '');
    $('.page2_yu').attr('onclick', '');

    $('.tancheng_lingjiang_bg').hide();
    $('.tancheng_jiang_bg').show();
    $('.tancheng_daojishi_bg').hide();
    var m = res.box.AwardID - 1;
    $('.tancheng_yiling_img').eq(m).show().siblings('.tancheng_yiling_img').hide();
    $(".tancheng_yiling_box").show();
    $('.tanceng').show();
}
/*表单提交*/
function form_sub() {
    var name = $("#name").val();
    if (name == "") {
        $.tishi("请输入姓名");
        return false;
    }
    var mobile = $("#mobile").val();
    if (mobile == "") {
        $.tishi("请输入电话");
        return false;
    } else {
        var re = /^1(3|4|5|7|8)\d{9}$/;
        if (!re.test(mobile)) {
            $.tishi("手机号错误");
            return false;
        }
    }
    /*取消点击事件*/
    $('.page1_form_but').attr('onclick', '');
    /*加载gif*/
    $(".jiazai").show();
    jQuery.ajax({
        type: 'post',
        url: ajaxUrl + "ChristmasUserLogin?Name=" + name + "&Mobile=" + mobile + "&OpenId=" + openId,
        dataType: "json",
        //data: { Name: name, Mobile: mobile,code:147258},
        success: function(res) {
            /*隐藏加载gif*/
            $(".jiazai").hide();
            if (res.result >= 1) {
                if (res.result == 1) {
                    part1();
                } else if (res.result == 2) {
                    part2();
                } else if (res.result == 3) {
                    part3();
                } else if (res.result == 4) {
                    part4();
                } else if (res.result == 5) {
                    part5(res);
                }
            } else {
                $.tishi(res.msg);
                $('.page1_form_but').attr('onclick', 'form_sub();');
                $('.page2_box').attr('onclick', 'lingjiang();');
                $('.page2_yu').attr('onclick', "popup_open('.shuoming_tanceng');popup_close('.page2_yu');");
            }

        }
    });

}

/*第二页盒子点击*/
function box(e) {
    $('.page2_box').removeClass('page2_box_huang');
    $('.page2_box').eq(e).addClass('page2_box_huang2').siblings('.page2_box').removeClass('page2_box_huang2');
    /*取消点击事件*/
    $('.page2_box').attr('onclick', '');
    $('.page2_yu').attr('onclick', '');
    $('.shuoming_tanceng').hide();
    jQuery.ajax({
        type: 'GET',
        url: ajaxUrl + "ChristmasUserGetBox?openId=" + openId,
        dataType: "json",
        success: function(res) {
            /*隐藏加载gif*/
            $(".jiazai").hide();
            if (res.result == 1) {
                part11();
            } else if (res.result == 2) {
                part2();
            } else if (res.result == 3) {
                part3();
            } else if (res.result == 4) {
                part4();
            } else if (res.result == 5) {
                part5(res);
            } else {
                $.tishi(res.msg);
                $('.page1_form_but').attr('onclick', 'form_sub();');
                $('.page2_box').attr('onclick', 'lingjiang();');
                $('.page2_yu').attr('onclick', "popup_open('.shuoming_tanceng');popup_close('.page2_yu');");
            }
        }
    });
}

/*领奖按钮点击*/
function lingjiang() {
    /*领奖按钮隐藏*/
    $(".tancheng_lingjiang_but").attr('onclick', '');
    $(".tancheng_lingjiang_box").attr('onclick', '');
    $(".tancheng_lingjiang_but").hide();
    /*领奖动效+期限隐藏*/
    $(".tancheng_lingjiang_box_huang").hide();
    $(".tancheng_lingjiang_qixian").hide();



    /*奖品*/
    jQuery.ajax({
        type: 'GET',
        url: ajaxUrl + "ChristmasUserLuckdraw?openId=" + openId,
        dataType: "json",
        success: function(res) {
            if (res.result == 5) {
                var m = res.box.AwardID - 1;
                $('.tancheng_lingjiang_box2 img').hide();
                $('.tancheng_lingjiang_box2 img').eq(m).show();
                $(".tancheng_lingjiang_box2").show();
            } else {
                $.tishi(res.msg);
                $(".tancheng_lingjiang_but").attr('onclick', 'lingjiang();');
                $(".tancheng_lingjiang_box").attr('onclick', 'lingjiang();');
            }
        }
    });

    /*标题*/
    $(".tancheng_lingjiang_title1").hide();
    $(".tancheng_lingjiang_title2").show();

}