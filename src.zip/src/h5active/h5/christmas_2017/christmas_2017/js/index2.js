var ajaxUrl = 'http://117.107.153.228:808/api/Christmas/';
var local = 'http://192.168.0.84/smy/christmas_2017/';

$(function(){
    //解决安卓手机软件盘问题
    $('.page1').height($(window).height());
    var starttime = new Date("2017/12/12 17:00");
    var endtime = new Date("2017/12/14 17:00");
    var nowtime = new Date();//此处须获取服务器时间

    //jQuery.ajax({
    //    type: 'GET',
    //    url: ajaxUrl+"GetServerDate",
    //    dataType: "json",
    //    data: {},
    //    success: function (res) {
    //        console.log(res);
    //    }
    //});

    var time = starttime - nowtime;
    var time2 = endtime - nowtime;
    //倒计时
    if(time>0&&time2>0){
        $('.tancheng_lingjiang_bg').hide();
        $('.tancheng_jiang_bg').hide();
        $('.tancheng_daojishi_bg').show();
        var setT=setInterval(function () {
            time=time-1000;
            if(time>0){
                var day = parseInt(time / 1000 / 60 / 60 / 24);
                var hour = parseInt(time / 1000 / 60 / 60 % 24);
                var minute = parseInt(time / 1000 / 60 % 60);
                var seconds = parseInt(time / 1000 % 60);
                if(day<10){day='0'+day;}
                if(hour<10){hour='0'+hour;}
                if(minute<10){minute='0'+minute;}
                if(seconds<10){seconds='0'+seconds;}
                $('.tancheng_daojishi_rel_p').eq(0).html(day);
                $('.tancheng_daojishi_rel_p').eq(2).html(hour);
                $('.tancheng_daojishi_rel_p').eq(4).html(minute);
                $('.tancheng_daojishi_rel_p').eq(6).html(seconds);
            }else{
                //倒计时结束，可以领奖弹层
                clearInterval(setT);
                $('.tancheng_daojishi_rel_p').eq(0).html('00');
                $('.tancheng_daojishi_rel_p').eq(2).html('00');
                $('.tancheng_daojishi_rel_p').eq(4).html('00');
                $('.tancheng_daojishi_rel_p').eq(6).html('00');
                $('.tancheng_daojishi_bg').hide();
                $('.tancheng_jiang_bg').hide();
                $('.tancheng_lingjiang_bg').show();
            }
        }, 1000);
    }else if(time<0&&time2>0){
        //没领过
        $('.tancheng_daojishi_bg').hide();
        $('.tancheng_lingjiang_bg').show();
        $('.tancheng_jiang_bg').hide();
    }else if(time<0&&time2<0){
        //活动结束
        $('.page1').show();
        $.tishi('活动已结束~');
        $('.page1_form_but').attr('onclick',"$.tishi('活动已结束~');");
        $('.page2').hide();
        $('.tanceng').hide();
        return false;
    }
    //var url = "https://open.weixin.qq.com/connect/oauth2/authorize";
    //url += "?appid=wxfc9793b7b7f4a417&redirect_uri=" + encodeURIComponent(location.href) + "&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect";
    //jQuery.ajax({
    //    type: 'GET',
    //    url: ajaxUrl+"GetWxConfig",
    //    dataType: "json",
    //    data: { name: name, mobile: mobile},
    //    success: function (res) {
    //        /*隐藏加载gif*/
    //        $(".jiazai").hide();
    //        /*离开动画*/
    //        $(".page1_form_box").addClass("page1_form_box2");
    //        /*进入第二页*/
    //        setTimeout(function(){
    //            $(".page2").show();
    //        },1600);
    //    }
    //});




    //$.getScript('http://res.wx.qq.com/open/js/jweixin-1.0.0.js',function(response,status){
    //    var appId;
    //    var timestamp;
    //    var nonceStr;
    //    var sign;
    //    $.get("http://api.hi-fan.cn/api/Share/ShareByWebChat",{url:location.href},function(data){
    //        if(data!=""){
    //            data=data.data;
    //            appId=data.appId;
    //            timestamp=data.timeStamp;
    //            nonceStr=data.nonceStr;
    //            sign=data.sign;
    //            wx.config({
    //                debug: false,
    //                appId: appId,
    //                timestamp: timestamp,
    //                nonceStr: nonceStr,
    //                signature: sign,
    //                jsApiList: [
    //                    'checkJsApi',
    //                    'onMenuShareTimeline',
    //                    'onMenuShareAppMessage'
    //                ]
    //            }); wx.ready(function () {
    //                var shareData = {
    //                    title: 'GoGoTalk双旦享好礼，玩转迪士尼！100%中奖！',
    //                    desc: '快来开启你的双旦礼物吧',
    //                    link: location.href,
    //                    imgUrl: local+'fenxiang.jpg'
    //                };
    //                wx.onMenuShareAppMessage(shareData);
    //                wx.onMenuShareTimeline(shareData);
    //            });
    //            wx.error(function (res) {
    //                //alert(res.errMsg);
    //            });
    //        }
    //    });
    //})
});

/* 音乐 */
function music_load(){
    if($(".music_num").attr("num") == "1"){
        $(".music_num").attr("num","2");
        $(".music_open").css("display","none");
        $(".music_close").css("display","block");
        document.getElementById("aud").pause();
    }else{
        $(".music_num").attr("num","1");
        $(".music_open").css("display","block");
        $(".music_close").css("display","none");
        document.getElementById("aud").play();
    }
}
/* iphone音乐播放 提交成功时调用*/
function page1_btu_succ(){
    $(".music_num").attr("num","1");
    $(".music_open").css("display","block");
    $(".music_close").css("display","none");
    document.getElementById("aud").play();
}

/*提示*/
jQuery.tishi = function (e) {
    $(".tishi span").html(e);
    $(".tishi").show();
    setTimeout(function () {
        $(".tishi").hide();
    },1800)
};

/*打开弹窗*/
function popup_open(e){
    $(e).show();
}
/*关闭弹窗*/
function popup_close(e){
    $(e).hide();
}

/*表单提交*/
function form_sub(){
    var name = $("#name").val();
    if (name == "") {
        $.tishi("请输入姓名");
        return false;
    }
    var mobile = $("#mobile").val();
    if (mobile == "") {
        $.tishi("请输入电话");
        return false;
    } else {
        var re =/^1(3|4|5|7|8)\d{9}$/;
        if (!re.test(mobile)) {
            $.tishi("手机号错误");
            return false;
        }
    }
    /*取消点击事件*/
    $('.page1_form_but').attr('onclick','');
    /*iphone音乐*/
    page1_btu_succ();
    /*加载gif*/
    $(".jiazai").show();


    //jQuery.ajax({
    //    type: 'post',
    //    url: ajaxUrl+"ChristmasUserLogin?Name=11&Mobile=13000000000&code=147258",
    //    dataType: "json",
    //    data: { name: name, mobile: mobile},
    //    success: function (res) {
    //        /*隐藏加载gif*/
    //        $(".jiazai").hide();
    //        /*离开动画*/
    //        $(".page1_form_box").addClass("page1_form_box2");
    //        /*进入第二页*/
    //        setTimeout(function(){
    //            $(".page2").show();
    //        },1600);
    //    }
    //});



}
/*第二页盒子点击*/
function box(e){
    $('.page2_box').removeClass('page2_box_huang');
    $('.page2_box').eq(e).addClass('page2_box_huang2').siblings('.page2_box').removeClass('page2_box_huang2');
    /*取消点击事件*/
    $('.page2_box').attr('onclick','');
    $('.page2_yu').attr('onclick','');
    $('.shuoming_tanceng').hide();
    setTimeout(function(){
        $('.tanceng').show();
    },1200);


    //jQuery.ajax({
    //    type: 'GET',
    //    url: ajaxUrl+"ChristmasUserGetBox?openId=147258",
    //    dataType: "json",
    //    data: { name: name, mobile: mobile},
    //    success: function (res) {
    //
    //    }
    //});
}

/*领奖按钮点击*/
function lingjiang(){
    if(time2<0){
        $.tishi("活动已结束");
        return false;
    }
    /*领奖按钮隐藏*/
    $(".tancheng_lingjiang_but").attr('onclick','');
    $(".tancheng_lingjiang_box").attr('onclick','');
    $(".tancheng_lingjiang_but").hide();
    /*领奖动效+期限隐藏*/
    $(".tancheng_lingjiang_box_huang").hide();
    $(".tancheng_lingjiang_qixian").hide();




    ///*奖品*/
    //jQuery.ajax({
    //    type: 'GET',
    //    url: ajaxUrl+"ChristmasUserLuckdraw?openId=147258",
    //    dataType: "json",
    //    data: { name: name, mobile: mobile},
    //    success: function (res) {
    //        $('.tancheng_lingjiang_box2 img').eq(1).show();
    //        $(".tancheng_lingjiang_box2").show();
    //
    //    }
    //});
    /*标题*/
    $(".tancheng_lingjiang_title1").hide();
    $(".tancheng_lingjiang_title2").show();

}