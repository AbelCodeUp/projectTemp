import React,{Component} from 'react';
export default class My_personCenter_bindPhone extends Component{
  constructor(){
    super();
  }
  render(){
    return (
      <div>
        绑定手机号码
      </div>
    )
  }
}
