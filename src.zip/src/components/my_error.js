import React, {Component} from 'react';
import {Link} from 'react-router';
import {hashHistory} from 'react-router';
import jQuery from '../js/jquery-3.2.0';

export default class My_order extends Component {
    render() {
        return (
            <div className="errorBox">
                <div className="errorImg">
                    <img src="../images/error1.png" alt=""/>
                </div>
            </div>
        )
    }
}
