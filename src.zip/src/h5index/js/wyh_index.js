
/*/!*当前已报名人数*!/
var wyh_people=document.getElementById('wyh_people');
var wyh_enroll=document.getElementById('wyh_enroll');
wyh_people.innerText=240+parseInt(getdate());
wyh_enroll.innerText="已报名："+(240+parseInt(getdate()))+"人";

/!*获取当前分钟*!/
function getdate(){
	var date=new Date()
return date.getMinutes();
}*/
