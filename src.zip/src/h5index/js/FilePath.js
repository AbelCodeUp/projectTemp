window.urls = 'http://testapi.hi-fan.cn/';//2.0接口地址
window.urlsHtt = 'http://testwx.hi-fan.cn/';//2.0H5地址
window.urlsguan = 'http://testwx.hi-fan.cn/';//2.0H5地址