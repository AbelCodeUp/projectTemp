/*function video_what(id){
  jQuery(".video_box").show();
  var videoid='http://one2more.oss-cn-beijing.aliyuncs.com/guanwang/videos/shipin'+id+'.mp4';
  jQuery("#video").attr("src",videoid);
}
$(function(){
  /!*关闭视频*!/
  jQuery(".video_box_close").click(function(){
    jQuery(".video_box").hide();
    jQuery("#video").attr("src",'');
  });
})*/
$(function(){
  jQuery('.shiping_zhezhao').click(function(){

    /*console.log(jQuery('.shiping video')[0].play());
    console.log(jQuery('.shiping video')[0].pause());*/
    if(jQuery('.shiping video')[0].paused){
      console.log(1);
      jQuery('.shiping video').css('z-index','888');
      jQuery('.shiping video')[0].play();
    }
  })
  jQuery('.shiping_zhezhao2').click(function(){

    /*console.log(jQuery('.shiping video')[0].play());
    console.log(jQuery('.shiping video')[0].pause());*/
    if(jQuery('.shiping2 video')[0].paused){
      console.log(1);
      jQuery('.shiping2 video').css('z-index','888');
      jQuery('.shiping2 video')[0].play();
    }
  })
})

function audioFn(obj,num){
  //var media = $(obj).find('audio')[0];
  $('.iconfont').removeClass('play');
  var media = $("#myAudio")[0];
  if(media.paused) {//播放
    // if(num==4){
    //   $(media).attr('src','audio/'+num+'.mp4');
    // }else{
      $(media).attr('src','audio/'+num+'.mp3');
    // }
    media.play();
    $(obj).find('i').addClass('play');
  } else {// 暂停
    $(media).attr('src','');
    media.pause();
    $(obj).find('i').removeClass('play');
  }
  var  is_playFinish = setInterval(function(){
    if(media.ended){
      window.clearInterval(is_playFinish);
      $(obj).find('i').removeClass('play');
    }
  }, 10);
}
