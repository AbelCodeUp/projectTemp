		var isPhone=false;
		var isPs=false;
		var isYan=false;
		var flag1=true;
		var flag2=true;
		var daojishit1=0;
		var daojishit2=0;
		var num1=60;
		var num2=60;
		//测试
		var urls = 'http://117.107.153.228:803/';//测试
		var urlsguan = 'http://wx.gogo-talk.com/h5test/'
		var url1;
		// 正式
		// var urls = 'https://hfapi.gogo-talk.com/';
		// var urlsguan = 'https://wx.gogo-talk.com/';
		var urlpay = urlsguan+'h5index/bulkNew.html';
		var goodsId=0;//全局记录点击的商品Id
		var channelId=0;
		var logins = 0;

		var bind_name="input";//定义所要绑定的事件名称
		var GroupID = 4;
		if(navigator.userAgent.indexOf("MSIE")!=-1){
				 bind_name="propertychange";//判断是否为IE内核 IE内核的事件名称要改为propertychange
		 }else if(navigator.userAgent.match(/android/i) == "android"){
				 bind_name = "keyup";
		}
		//var urls = 'http://learnapi.gogo-talk.com:8333/';//正式
	//分享
	share();
	function share(){
		 $.getScript('https://res.wx.qq.com/open/js/jweixin-1.2.0.js', function (response, status) {
			$.get(urls+"api/Share/ShareByWebChat", { url: location.href}, function (data) {
				try {
					data = eval("(" + data + ")");
				} catch (e) { }
				if (data.result == 1) {
					console.log(data.data.sign);
					wx.config({
						debug: false,
						appId: data.data.appId,
						timestamp: data.data.timeStamp,
						nonceStr: data.data.nonceStr,
						signature: data.data.sign,
						jsApiList: [
						'checkJsApi',
						'onMenuShareTimeline',
						'onMenuShareAppMessage'
						]
					});
					wx.ready(function () {
						var shareData = {
							title: '我正在“hi翻外教课堂”进行【超值团购】，快来一起参加吧！',
							desc: '小班课，趣味化互动教学；来hi翻外教课堂，和小伙伴一起跟着外教学地道英语。',
							link: urlpay,
							imgUrl: 'http://wx.gogo-talk.com/images/one2more.png'
						};
						wx.onMenuShareAppMessage(shareData);
						wx.onMenuShareTimeline(shareData);
					});
					wx.error(function (res) {
													// alert(res.errMsg);
												});
				} else {
					console.log("异常错误");
				}
			});
		})
	 }

touch.on('.loginShow','tap',function(){//切换到登录
	$(".registerbox").hide();
	$(".loginbox").show();
	$(".resetbox").hide();
	$(".confirmBox").hide();
	formYan('#logPhone','#logPs','#loginBtn');
	cleanFn('#regPhone','#regPs','#registerBtn','#regYanzhen');
})

touch.on('.registerShow','tap',function(){//切换到注册
	$(".registerbox").show();
	$(".loginbox").hide();
	$(".resetbox").hide();
	$(".confirmBox").hide();
	formYan('#regPhone','#regPs','#registerBtn','#regYanzhen','#yanzhenNum');
	cleanFn('#resetPhone','#resetPs','#resetBtn','#resetYan');
	cleanFn('#logPhone','#logPs','#loginBtn');
})

touch.on('.resetShow','tap',function(){//切换到重置密码
	$(".loginbox").hide();
	$(".resetbox").show();
	$(".confirmBox").hide();
	formYan('#resetPhone','#resetPs','#resetBtn','#resetYan','#yanzhenNum2');
	cleanFn('#logPhone','#logPs','#loginBtn');
})

touch.on('.denlvbox','tap',function(e){//弹层的关闭
	if($(e.target).hasClass('denlvbox')){
		$(this).hide();
		$(".registerbox").show();
	}
})

touch.on('.confirmWord','tap',function(e){//切换到确认订单
	$(".confirmBox").hide();
	$(".loginbox").show();
	formYan('#logPhone','#logPs','#loginBtn');
	cleanFn('#logPhone','#logPs','#loginBtn');
})

//倒计时
function daojishi(phone,obj,type){
	$(phone).prop('disabled',true).css({'background':'#fff'});
	if(type==1){
		daojishit1 = setInterval(function(){
			num1--;
			$(obj).html(num1+'s后重新获取').removeClass("yanzhenma-active");
					//$(".yanzhenma").unbind('click');
					if(num1<=0){
						clearInterval(daojishit1);
						num1 = 60;
							// $(obj).html('获取验证码').addClass("yanzhenma-active");
							$(obj).html('重新发送');
							$(phone).prop('disabled',false).css({'background':'#fff'});
							flag1 = true;
						}
					},1000)
	}else if(type==2){
		daojishit2 = setInterval(function(){
			num2--;
			$(obj).html(num2+'s后重新获取').removeClass("yanzhenma-active");
			//$(".yanzhenma").unbind('click');
			if(num2<=0){
				clearInterval(daojishit2);
				num2 = 60;
				// $(obj).html('获取验证码').addClass("yanzhenma-active");
				$(obj).html('重新发送');
				$(phone).prop('disabled',false).css({'background':'#fff'});
				flag2 = true;
			}
		},1000)
	}

}

 function GetCookie(sName) {
	var aCookie = document.cookie.split("; ");
	for (var i = 0; i < aCookie.length; i++) {
		var aCrumb = aCookie[i].split("=");
		if (sName == aCrumb[0])
			return unescape(aCrumb[1]);
	}
	return null;
}

		//清空
function cleanFn(phone,ps,queren,regyan){
	var argumentsObj = arguments;
	$(phone).val('');
	$(phone).parent('.formbox').removeClass('formbox_active');
	$(phone).nextAll('.error').hide().html('');
	$(ps).val('');
	$(ps).parent('.formbox').removeClass('formbox_active');
	$(ps).nextAll('.error').hide().html('');
	if(argumentsObj.length==4){
		$(regyan).val('');
		$(regyan).parent('.formbox').removeClass('formbox_active');
		$(regyan).nextAll('.error').hide().html('');
	}
	$(queren).removeClass('register_active');
	$("#yanzhenNum").removeClass('yanzhenNum');
	$("#yanzhenNum2").removeClass('yanzhenNum');
}
//表单验证
function formYan(phone,ps,queren,regYan,huoqu){
	var argumentsObj = arguments;
	$(phone).blur(function(){
		var reg = /^1[0-9]{10}$/;
		var val = $(this).val();

		if(val == ""){
		 $(phone).parent('.formbox').addClass('formbox_active');
		 $(phone).nextAll('.error').show().html('手机号不能为空!');
	 }else{
		if(!reg.test(val)){
		 isPhone=false;
		 $(phone).parent('.formbox').addClass('formbox_active');
		 $(phone).nextAll('.error').show().html('手机号只能是11位的数字!');
	 }else{
		 isPhone=true;
		 $(phone).parent('.formbox').removeClass('formbox_active');
		 $(phone).nextAll('.error').hide().html('');
	 }
 }
})
$(phone).bind(bind_name,function(event){
	event.stopPropagation();
	var reg = /^1[0-9]{10}$/;
	var val = $(this).val();
	if(reg.test(val)){
		isPhone=true;
	}else{
		isPhone=false;
	}
	if(isPhone){
		$(huoqu).addClass('yanzhenNum')
	}else{
		$(huoqu).removeClass('yanzhenNum')
	}

	if(argumentsObj.length >= 4){
		if(isPhone && isPs && isYan){
			$(queren).addClass('register_active')
		}else{
			$(queren).removeClass('register_active')
		}
	}else{
		if(isPhone && isPs){
			$(queren).addClass('register_active')
		}else{
			$(queren).removeClass('register_active')
		}
	}
})

$(ps).blur(function(){
	var reg = /^[0-9a-zA-Z]{6,}$/;
	var val = $(this).val();
	if(val == ""){
		isPs=false;
		$(ps).parent('.formbox').addClass('formbox_active');
		$(ps).nextAll('.error').show().html('密码不能为空!');
	}else{
		if(!reg.test(val)){
			isPs=false;
			$(ps).parent('.formbox').addClass('formbox_active');
			$(ps).nextAll('.error').show().html('密码只能是数字或字母!');
		}else{
			isPs=true;
			$(ps).parent('.formbox').removeClass('formbox_active');
			$(ps).nextAll('.error').hide().html('');
		}
	}
})
$(ps).bind(bind_name,function(event){
	event.stopPropagation();
	var reg = /^[0-9a-zA-Z]{6,}$/;
	var val = $(this).val();
	if(reg.test(val)){
		isPs=true;
	}else{
		isPs=false;
	}
	if(argumentsObj.length >= 4){
		if(isPhone && isPs && isYan){
			$(queren).addClass('register_active')
		}else{
			$(queren).removeClass('register_active')
		}
	}else{
		if(isPhone && isPs){
			$(queren).addClass('register_active')
		}else{
			$(queren).removeClass('register_active')
		}
	}
})

$(regYan).blur(function(){
	var reg = /^[0-9]{4}$/;
	var val = $(this).val();
	if(val == ""){
		isYan=false
		$(regYan).parent('.formbox').addClass('formbox_active');
		$(regYan).nextAll('.error').show().html('验证码不能为空!');
	}else{
		if(!reg.test(val)){
			isYan=false;
			$(regYan).parent('.formbox').addClass('formbox_active');
			$(regYan).nextAll('.error').show().html('验证码只能是4位的数字!');
		}else{
			isYan=true;
			$(regYan).parent('.formbox').removeClass('formbox_active');
			$(regYan).nextAll('.error').hide().html('');
		}
	}
})
$(regYan).bind(bind_name,function(event){
	event.stopPropagation();
	var reg = /^[0-9]{4}$/;
	var val = $(this).val();
	if(reg.test(val)){
		isYan=true;
	}else{
		isYan=false;
	}
	if(argumentsObj.length >= 4){
		if(isPhone && isPs && isYan){
			$(queren).addClass('register_active')
		}else{
			$(queren).removeClass('register_active')
		}
	}else{
		if(isPhone && isPs){
			$(queren).addClass('register_active')
		}else{
			$(queren).removeClass('register_active')
		}
	}
})
}

//验证码
touch.on('#yanzhenNum','tap',function(){
	if(flag1){
		flag1=false;
		if($(this).hasClass('yanzhenNum')){
			num1=60;
			daojishi('#regPhone','#yanzhenNum',1);
			$.get(urls+'api/Register/SendPhoneCode',{
				Phone:$('#regPhone').val()
			},function(data){
				if(data.result == 1){
					$("#yanzhenNum").html("获取验证码").removeClass("yanzhenNum");

				}
			})

		}
	}
})

touch.on('#yanzhenNum2','tap',function(){
	if(flag2){
		flag2=false;
		if($(this).hasClass('yanzhenNum')){
			num2=60;
			daojishi('#resetPhone','#yanzhenNum2',2);
			$.get(urls+'api/Register/SendPhoneCodeByPwd',{
				Phone:$('#resetPhone').val()
			},function(data){
				if(data.result == 1){
					$("#yanzhenNum2").html("获取验证码").removeClass("yanzhenNum");
				}
			})
		}
	}
})

function GetQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null)return unescape(r[2]);
	return null;
}

	 var access_code = GetQueryString('code');
	 channelId=GetQueryString('channelId');
	 if(!channelId){channelId=0}
	 	if (access_code != null && access_code != "") {
	 		jQuery.get(urls+"api/User/LoginByWeChat?code=" + access_code, function(data) {
		if (data.result == 1) {//新用户
			var openid = data.msg;
			document.cookie = "openId=" + openid;
			 touch.on('.btn1','tap',function(){//切换到注册
			 	$(".denlvbox").css('height',$(window).height()).show();
			 	$(".registerbox").show();
			 	$(".loginbox").hide();
			 	$(".resetbox").hide();
			 	$(".confirmBox").hide();
			 	$(".confirmBox").attr('goodsId',3);
			 	$(".confirmBox").attr('goodsName','60课时');
			 	$(".confirmBox").attr('price',1688);
			 	$('.confirmCon h2:nth-child(1)').text('购买课程：60课时');
			 	$('.confirmCon h2:nth-child(2)').text('价格：¥1688');
			 	$('.groupOk').hide();
			 	formYan('#regPhone','#regPs','#registerBtn','#regYanzhen','#yanzhenNum');
			 })
		}
		else if (data.result == 2) {//已注册的用户

			document.cookie = "Tonken=" + data.data.userToken;
			firstGet();

			touch.on('.btn1','tap',function(){
				$.ajax({
					type: "GET",
					url:urls+'api/StuGroup/IsOpenGroup?GroupID='+GroupID,
					headers: { Authorization: GetCookie('Tonken') },
					dataType: "json",
					// data:{GroupID:groupId, GoodsID:goodsId,OrderId:1969},
					success: function (json) {
						if (json.result == 1) {
							$('.groupOk').show();
							touch.on('.group-clear','tap',function(){
								$('.groupOk').hide();
							})
							touch.on('.group-ok','tap',function(){
								$('.groupOk').hide();

								$(".denlvbox").css('height',$(window).height()).show();
								$(".registerbox").hide();
								$(".loginbox").hide();
								$(".resetbox").hide();
								$(".confirmBox").show();
								$(".confirmBox").attr('goodsId',3);
								$(".confirmBox").attr('goodsName','60课时');
								$(".confirmBox").attr('price',1688);
								$('.confirmCon h2:nth-child(1)').text('购买课程：60课时');
								$('.confirmCon h2:nth-child(2)').text('价格：¥1688');
							})
						}else{
							alert('团购已开启，请重新进入页面');
						}
					}
				});
			})

}else if(data.result>=1000){//Tonken过期
	document.cookie = "Tonken="+'';
	window.location.reload();
}else if(data.result == 0){
	location.href = location.href.split('?')[0];
}
})
} else {
	var curUrl = location.href;
	var url = "https://open.weixin.qq.com/connect/oauth2/authorize";
	url += "?appid=wxcd96ac91c795045f&redirect_uri=" + encodeURIComponent(curUrl) + "&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect";
	location.href = url;
}
//注册
touch.on('#registerBtn','tap',function(){
	layer.load(1, {shade: false})
	$.get(urls+'api/Register/UserRegister',{
		Phone:$('#regPhone').val(),
		Code:$('#regYanzhen').val(),
		OpenId:GetCookie('openId'),
		Password:$('#regPs').val(),channelId:channelId
	},function(data){
		if(data.result==2){
			$(".registerbox").hide();
			$(".loginbox").hide();
			$(".resetbox").hide();
				// $('.groupOk').show();
			//$(".confirmBox").show();
			
			document.cookie = "Tonken=" + data.data.userToken;
			var curUrl = location.href.substring(0,location.href.indexOf("code"));
		             var url = "https://open.weixin.qq.com/connect/oauth2/authorize";
		             url += "?appid=wxcd96ac91c795045f&redirect_uri=" + encodeURIComponent(curUrl) + "&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect";
		             location.href = url;
			// firstGet(0);
		}else{
			alert(data.msg);
		}
	})
})

//登录
touch.on('#loginBtn','tap',function(){
	$.post(urls+'api/Register/Login',{
		UserName:$('#logPhone').val(),
		Password:$('#logPs').val()
	},function(data){
		if(data.result==2){
			$(".loginbox").hide();
			$(".confirmBox").show();//确认订单显示
			firstGet();
		}else{
			alert(data.msg);
		}
	})
})

//重置密码
touch.on('#resetBtn','tap',function(){
	$.post(urls+'api/Register/ChangePwdByPoneCode',{
		Phone: $('#resetPhone').val(),
		Code: $('#resetYan').val(),
		NewPsw: $('#resetPs').val(),
		ConfirmPsw:  $('#resetPs').val()
	},function(data){
		if(data.result==1){
			layer.msg(data.msg);
			cleanFn('#resetPhone','#resetPs','#resetBtn','#resetYan');
			document.cookie = "Tonken=" + '';
			$('.resetbox').hide();
			$('.loginbox').show();
		}else{
			layer.msg(data.msg);
		}
	})
})

//确认支付
//确认支付点击事件绑定的函数
var appId="";
var timeStamp="";
var nonceStr="";
var package="";
var signType="";
var paySign="";
var goodId="";
var orderId = 0;
function onBridgeReady(){
	// var dataObj=JSON.parse('{ "appId" : "'+appId+'","timeStamp" : "'+timeStamp+'","nonceStr" : "'+nonceStr+'","package" : "'
	//   +package+'","signType" : "'+signType+'","paySign" :  "'+paySign+'"}');
	var dataObj=JSON.parse('{ "appId" : "'+appId+'","timeStamp" : "'+timeStamp+'","nonceStr" : "'+nonceStr+'","package" : "'
		+package+'","signType" : "'+signType+'","paySign" :  "'+paySign+'"}');
	WeixinJSBridge.invoke('getBrandWCPayRequest',dataObj , function(res) {

		if (res.err_msg == "get_brand_wcpay_request:ok") {//调取微信支付接口成功
			// firstGet(1);
			// $('.confirmBox').hide();

		} // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。
		else {//调取微信接口失败，返回首页，重新去购买
			$('.denlvbox').hide();
			firstGet();
			location.reload();
		}
	});
}

function callPay(){
	if (typeof WeixinJSBridge == "undefined"){
		if( document.addEventListener ){
			document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
		}else if (document.attachEvent){
			document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
			document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
		}
	}else{
		onBridgeReady();
	}
}
var falg = true;
var payTimer = null;
var payTimer1 = null;
touch.on('.payBtn','tap',function(){
	if(falg){
		falg = false;
		//var urlObj =
		//console.log(urlObj);
		logins = layer.load(1, {shade: false})
		goodsId=$('.confirmBox').attr('goodsId');
		var goodsName=$('.confirmBox').attr('goodsName');
		var price=$('.confirmBox').attr('price');
		var postUrl = urls+'api/Order/PostGroupZhiFu';
		//微信
		jQuery.ajax({
			url: postUrl,
			headers: {
				Authorization: GetCookie('Tonken')
			},
			type: "post",
			data: {
				ZhiFuType :2,
				OrderNum :"",
				GoodsId :goodsId,
				GoodsName :goodsName,
				GPrice:price,
				Remarks:"",
				CouponId :0,
				PaySource :1,
				GroupType:1,
				GroupID:GroupID,
				OpenGroupID:0,
				ChannelID:channelId
			},
			success: function (data) {
				layer.close(logins);
				if (data.result == 1) {//调取微信接口
					appId= data.data.appId;
					timeStamp=data.data.timeStamp;
					nonceStr = data.data.nonceStr;
					package = data.data.package;
					signType = data.data.signType;
					paySign=  data.data.paySign;
					orderId = data.data.orderId;
					//goodId=goodsId;
					payTimer = setInterval(function(){
						IsOpenGroup(function(json){
							if (json.result == -1) {
								$('.confirmBox').hide();
								payTimer1 = setInterval(function(){
									$.ajax({
										type: "GET",
										url:urls+'api/StuGroup/GetMyStartGroupInfo?GroupID='+GroupID,
										headers: { Authorization:GetCookie('Tonken') },
										dataType: "json",
										async: false,
										success: function (json) {
											if (json.result == 1) {
												layer.msg('团购成功');
												OpenGroupID = json.data.OpenGroupID;
												if(OpenGroupID ){
													localStorage.setItem('OpenGID',OpenGroupID);
												}else{
													OpenGroupID = localStorage.getItem('OpenGID');
												}
												
												url1 = urlsguan+'h5index/buySuccess.html?OpenGroupID='+OpenGroupID+'&type=60';
												window.location.href=url1;
												
												urlpay = urlsguan+'h5index/groupNew.html?OpenGroupID='+OpenGroupID;
												share();

											}
										}
									});
									clearInterval(payTimer);
									clearInterval(payTimer1);
								},500);
							}
						})
					},1000)

					callPay();
				} else if (data.result >= 1000) {//Token过期后，重新获取Token
					document.cookie = "Tonken=" + '';
					window.location.reload();
				} else {//data.result==0 订单生成，但没有支付
					//location.href=location.href.split('/h5index')[0] + "#/My_order";
					alert(data.msg);
				}
			}
		});
	}
})


//苹果微信端的返回按钮
pushHistory();
function pushHistory(){
	window.addEventListener("popstate", function(e){
		// location.href = 'http://wx.gogo-talk.com/h5test/index.html';
		//window.history.back();
		//在历史记录中后退,这就像用户点击浏览器的后退按钮一样。

		//window.history.go(-1);
		//你可以使用go()方法从当前会话的历史记录中加载页面（当前页面位置索引值为0，上一页就是-1，下一页为1）。

		//self.location=document.referrer;
		//可以获取前一页面的URL地址的方法,并返回上一页。
	}, false);
	var state = {
		title:"",
		url: "#"
	};
	window.history.pushState(state, "", "#");
};
	$('.denlvbox input').focus(function(){
		$('.denlvbox').css({
			'position':'absolute'
		});
		document.body.scrollTop = document.documentElement.scrollTop = 100;
	})
	$('.denlvbox input').blur(function(){
		$('.denlvbox').css({
			'position':'fixed'
		});
	})
// lhb


// var groupId = 0;
var OpenGroupID ;
var timer = null;
var  timenow ;
function firstGet(type){
	$.ajax({
		type: "GET",
		url:urls+'api/StuGroup/GetMyStartGroupInfo?GroupID='+GroupID,
		headers: { Authorization:GetCookie('Tonken') },
		dataType: "json",
		async: false,
		success: function (json) {
			if (json.result == 1) {

				$('.btn1').hide();
				$('.btn2').text('邀请好友参团').show();

				touch.on('.btn2','tap',function(){
					$('.fuceng').show();
				})
				if(json.data.JoinCount<6){
					$('.progress').css('width','7%');
				}else if(json.data.JoinCount<12&&json.data.JoinCount>6){
					$('.progress').css('width','35%');
					$('.circle1').addClass('circleIn');
				}else if(json.data.JoinCount<18&&json.data.JoinCount>12){
					$('.progress').css('width','66%');
					$('.circle1,.circle2').addClass('circleIn');
				}else if(json.data.JoinCount>=18){
					$('.progress').css('width','100%');
					$('.circle').addClass('circleIn');
				}else if (json.data.JoinCount==6) {
					$('.progress').css('width','15%');
					$('.circle1').addClass('circleIn');
				}else if (json.data.JoinCount==12) {
					$('.progress').css('width','50%');
					$('.circle1,.circle2').addClass('circleIn');
				}
						//倒计时
				clearInterval(timer);
				timenow =  json.data.EndTime
				if(json.data.EndTime<=0){
					dataFormat(timenow);
					$(".btn1").show();
					$(".btn2").hide();
					$(".btn3").hide();
					$('.lhb-time').text('剩余时间: 3天 00:00:00');
				}else{
					dataFormat(timenow);
					timer = setInterval(function(){
					if (timenow == 0) {
						clearInterval(timer);
						$(".btn1").show();
						$(".btn2").hide();
						$(".btn3").hide();
						$('.lhb-time').text('剩余时间: 3天 00:00:00');
						$('.head-img').hide();
						$('.photo-box').css('display','none').empty();
						$('.progress').css('width','0');
						$('.circle').removeClass('circleIn');
						getUpdateGroupStatus();
						return;
					}
					timenow--;
					dataFormat(timenow);
					},1000);
				}
				// 头像
				if(json.result == 1){
					$('.head-img').show();
					$('.head-img').html("已参团人员("+json.data.JoinCount+")");
					$('.photo-box').css('display','block');
					var html='';
					for(var i=0;i<json.data.JoinStudent.length;i++){
						if(json.data.JoinStudent.length>7){
							for (var i = 0; i < json.data.JoinStudent.length; i++) {
								html = '<li><img src="' + json.data.JoinStudent[i].Headimgurl + '" alt=""></li>'
								$(html).appendTo('.photo-box');
							}
							// html = '<li><img src="' + json.data.JoinStudent[6].Headimgurl + '" alt=""><div class="yinying">' + json.data.JoinCount + '</div></li>';
							// $(html).appendTo('.photo-box');
							return; 
						}else{
							html = '<li><img src="'+json.data.JoinStudent[i].Headimgurl+'" alt=""></li>'
							$(html).appendTo('.photo-box');
						}
					}
				}

				OpenGroupID = json.data.OpenGroupID;
				if(OpenGroupID ){
					localStorage.setItem('OpenGID',OpenGroupID);
				}else{
					OpenGroupID = localStorage.getItem('OpenGID');
				}
				if (type == 1) {
					url1 = urlsguan+'h5index/buySuccess.html?OpenGroupID='+OpenGroupID+'&type=60';
					window.location.href=url1;
				}
				urlpay = urlsguan+'h5index/groupNew.html?OpenGroupID='+OpenGroupID;
				share();

			}
		}
	});
}
function getGroupInfomation(){
	$.ajax({
		type: "GET",
		url:urls+'api/StuGroup/GetGroupInfo?GroupID='+GroupID,
		headers: { Authorization:GetCookie('Tonken') },
		dataType: "json",

		success: function (json) {
			$('.lhb-container>h3').text(json.data.GroupTitle);
			$('.money .money-jin').text('￥'+json.data.GPrice);
			$('.money .money-keshi').text(json.data.ClassHours);
			goodsId = json.data.GoodsID;
			// groupId = json.data.GroupID ;
		}
	});
}

function getUpdateGroupStatus(){
	$.ajax({
		type: "GET",
		url:urls+'api/StuGroup/UpdateGroupStatus?OpenGroupID='+OpenGroupID,
		headers: { Authorization:GetCookie('Tonken') },
		dataType: "json",
		success: function  (json) {
		}
	});	
}
var timer1 = null;
function BuyGroupName(){
	clearInterval(timer1);
	$.ajax({
		type: "GET",
		url:urls+'/api/StuGroup/BuyGroupName',
		dataType: "json",
		success: function  (json) {
			var phoneNum = json.data.PhoneList;
			$('.join').html( '用户 '+phoneNum[0]+' 参团成功！');
			$('.join').animate({right:'4.5rem'},9500,'linear',function(){
				$('.join').css({right:'-4.6rem'})
			})
			var i = 1 ;
			var join;
			timer1 = setInterval(function(){
				if (i>=phoneNum.length) return;
				if (json.data.GroupTypeList[i] == 0) {
					join = '用户 '+phoneNum[i]+' 参团成功！';
				}else{
					join = '用户 '+phoneNum[i]+' 开团成功！';
				}
				
				$('.join').html(join);
				$('.join').animate({right:'4.5rem'},9500,'linear',function(){
					$('.join').css({right:'-4.6rem'})
				})
				i++;
			},10000)
		}
	}); 
}

function IsOpenGroup(callback){
	$.ajax({
		type: "GET",
		url:urls+'api/StuGroup/IsOpenGroup?GroupID='+GroupID,
		headers: { Authorization: GetCookie('Tonken') },
		dataType: "json",
		async: false,
		// data:{GroupID:groupId, GoodsID:goodsId,OrderId:1969},
		success: function (json) {
			callback(json);
		}
	});
}

 BuyGroupName();
 getGroupInfomation();

 touch.on('.fuceng','tap',function(){
	$('.fuceng').hide();
})

 function dataFormat(time){
	var days =Math.floor(time/(24*3600));
	var leave1=time%(24*3600)    //计算天数后剩余的毫秒数
	var hours=Math.floor(leave1/3600);
	// var hour = Math.floor(time-(day*(60*60*24));
	var leave2=leave1%3600;       //计算小时数后剩余的毫秒数
	var minutes=Math.floor(leave2/60);

	var leave3=leave2%60;  //计算分钟数后剩余的毫秒数
	var seconds=Math.round(leave3);
	days=days<10?'0'+days:days;
	hours=hours<10?'0'+hours:hours;
	minutes=minutes<10?'0'+minutes:minutes;
	seconds=seconds<10?'0'+seconds:seconds;
	$('.lhb-time').text('剩余时间：'+days+'天'+hours+':'+minutes+":"+seconds);
}
$(".mytv").on("click", function () {
  var myvideo = document.getElementById("myvideo");
  myvideo.style.zIndex="22"
  var videos = document.getElementById("videos");
  videos.play();
})  