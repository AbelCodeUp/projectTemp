		var isPhone=false;
		var isPs=false;
		var isYan=false;
		var flag1=true;
		var flag2=true;
		var daojishit1=0;
		var daojishit2=0;
		var num1=60;
		var num2=60;

    var bind_name="input";//定义所要绑定的事件名称
    if(navigator.userAgent.indexOf("MSIE")!=-1){
      bind_name="propertychange";//判断是否为IE内核 IE内核的事件名称要改为propertychange
    }else if(navigator.userAgent.match(/android/i) == "android"){
      bind_name = "keyup";
    }

		// alert("4444555555");
		var urls = 'http://learnapi.gogo-talk.com:8333/'//正式
		//var urls = 'http://49.4.128.115:803/';//测试
    touch.on('.loginShow','tap',function(){//切换到登录
      $(".registerbox").hide();
      $(".loginbox").show();
      $(".resetbox").hide();
      $(".confirmBox").hide();
      formYan('#logPhone','#logPs','#loginBtn');
      cleanFn('#regPhone','#regPs','#registerBtn','#regYanzhen');
    })

    touch.on('.registerShow','tap',function(){//切换到注册
      $(".registerbox").show();
      $(".loginbox").hide();
      $(".resetbox").hide();
      $(".confirmBox").hide();
      formYan('#regPhone','#regPs','#registerBtn','#regYanzhen','#yanzhenNum');
      cleanFn('#logPhone','#logPs','#loginBtn');
    })

    touch.on('.resetShow','tap',function(){//切换到重置密码
      $(".loginbox").hide();
      $(".resetbox").show();
      $(".confirmBox").hide();
      formYan('#resetPhone','#resetPs','#resetBtn','#resetYan','#yanzhenNum2');
      cleanFn('#logPhone','#logPs','#loginBtn');
    })

    touch.on('.denlvbox','tap',function(e){//弹层的关闭
      if($(e.target).hasClass('denlvbox')){
        $(this).hide();
        $(".registerbox").show();
      }
    })

    touch.on('.confirmWord','tap',function(e){//切换到确认订单
      $(".confirmBox").hide();
      $(".loginbox").show();
      formYan('#logPhone','#logPs','#loginBtn');
      cleanFn('#logPhone','#logPs','#loginBtn');
    })

		// alert("4444555555666666");
		//倒计时
		function daojishi(phone,obj,type){
		    $(phone).prop('disabled',true).css({'background':'#fff'});
		    if(type==1){
		    	daojishit1 = setInterval(function(){
			        num1--;
			        $(obj).html(num1+'s后重新获取').removeClass("yanzhenma-active");
			        //$(".yanzhenma").unbind('click');
			        if(num1<=0){
			            clearInterval(daojishit1);
			            num1 = 60;
			            $(obj).html('获取验证码').addClass("yanzhenma-active");
			            $(phone).prop('disabled',false).css({'background':'#fff'});
			     		flag1 = true;
			        }
			    },1000)
		    }else if(type==2){
		    	daojishit2 = setInterval(function(){
			        num2--;
			        $(obj).html(num2+'s后重新获取').removeClass("yanzhenma-active");
			        //$(".yanzhenma").unbind('click');
			        if(num2<=0){
			            clearInterval(daojishit2);
			            num2 = 60;
			            $(obj).html('获取验证码').addClass("yanzhenma-active");
			            $(phone).prop('disabled',false).css({'background':'#fff'});
			     		flag2 = true;
			        }
			    },1000)
		    }

		}

		function GetCookie(sName) {
            var aCookie = document.cookie.split("; ");
            for (var i = 0; i < aCookie.length; i++) {
                var aCrumb = aCookie[i].split("=");
                if (sName == aCrumb[0])
                    return unescape(aCrumb[1]);
            }
            return null;
        }

		//清空
		function cleanFn(phone,ps,queren,regyan){
			var argumentsObj = arguments;
			$(phone).val('');
			$(phone).parent('.formbox').removeClass('formbox_active');
			$(phone).nextAll('.error').hide().html('');
			$(ps).val('');
			$(ps).parent('.formbox').removeClass('formbox_active');
			$(ps).nextAll('.error').hide().html('');
			if(argumentsObj.length==4){
				$(regyan).val('');
				$(regyan).parent('.formbox').removeClass('formbox_active');
				$(regyan).nextAll('.error').hide().html('');
			}
			$(queren).removeClass('register_active')
		}
    //表单验证
		function formYan(phone,ps,queren,regYan,huoqu){
		    var argumentsObj = arguments;
		    $(phone).blur(function(){
		        var reg = /^1[0-9]{10}$/;
		        var val = $(this).val();
          console.log(val);
          if(val == ""){
		        	$(phone).parent('.formbox').addClass('formbox_active');
		        	$(phone).nextAll('.error').show().html('手机号不能为空!');
		        }else{
		            if(!reg.test(val)){
		            	isPhone=false;
		                $(phone).parent('.formbox').addClass('formbox_active');
			        	$(phone).nextAll('.error').show().html('手机号只能是11位的数字!');
		            }else{
		            	isPhone=true;
		                $(phone).parent('.formbox').removeClass('formbox_active');
			        	$(phone).nextAll('.error').hide().html('');
		            }
		        }
		    })
		    $(phone).bind(bind_name,function(event){
          event.stopPropagation();
          var reg = /^1[0-9]{10}$/;
		        var val = $(this).val();
		        if(reg.test(val)){
		        	isPhone=true;
		        }else{
		        	isPhone=false;
		        }
		        if(isPhone){
		        	$(huoqu).addClass('yanzhenNum')
		        }else{
		        	$(huoqu).removeClass('yanzhenNum')
		        }

		        if(argumentsObj.length >= 4){
		        	if(isPhone && isPs && isYan){
		        		$(queren).addClass('register_active')
		        	}else{
		        		$(queren).removeClass('register_active')
		        	}
		        }else{
		        	if(isPhone && isPs){
		        		$(queren).addClass('register_active')
		        	}else{
		        		$(queren).removeClass('register_active')
		        	}
		        }
		    })

		    $(ps).blur(function(){
		        var reg = /^[0-9a-zA-Z]{6,}$/;
		        var val = $(this).val();
		        if(val == ""){
		        	isPs=false;
		            $(ps).parent('.formbox').addClass('formbox_active');
		        	$(ps).nextAll('.error').show().html('密码不能为空!');
		        }else{
		            if(!reg.test(val)){
		            	isPs=false;
		                $(ps).parent('.formbox').addClass('formbox_active');
			        	$(ps).nextAll('.error').show().html('密码只能是数字或字母!');
		            }else{
		            	isPs=true;
		            	$(ps).parent('.formbox').removeClass('formbox_active');
			        	$(ps).nextAll('.error').hide().html('');
		            }
		        }
		    })
		    $(ps).bind(bind_name,function(event){
          event.stopPropagation();
          var reg = /^[0-9a-zA-Z]{6,}$/;
		        var val = $(this).val();
		        if(reg.test(val)){
		        	isPs=true;
		        }else{
		        	isPs=false;
		        }
		        if(argumentsObj.length >= 4){
		        	if(isPhone && isPs && isYan){
		        		$(queren).addClass('register_active')
		        	}else{
		        		$(queren).removeClass('register_active')
		        	}
		        }else{
		        	if(isPhone && isPs){
		        		$(queren).addClass('register_active')
		        	}else{
		        		$(queren).removeClass('register_active')
		        	}
		        }
		    })

		    $(regYan).blur(function(){
		        var reg = /^[0-9]{4}$/;
		        var val = $(this).val();
		        if(val == ""){
		        	isYan=false
		            $(regYan).parent('.formbox').addClass('formbox_active');
		        	$(regYan).nextAll('.error').show().html('验证码不能为空!');
		        }else{
		            if(!reg.test(val)){
		            	isYan=false;
		                $(regYan).parent('.formbox').addClass('formbox_active');
			        	$(regYan).nextAll('.error').show().html('验证码只能是4位的数字!');
		            }else{
		            	isYan=true;
		            	$(regYan).parent('.formbox').removeClass('formbox_active');
			        	$(regYan).nextAll('.error').hide().html('');
		            }
		        }
		    })
		    $(regYan).bind(bind_name,function(event){
          event.stopPropagation();
          var reg = /^[0-9]{4}$/;
		        var val = $(this).val();
		        if(reg.test(val)){
		        	isYan=true;
		        }else{
		        	isYan=false;
		        }
		        if(argumentsObj.length >= 4){
		        	if(isPhone && isPs && isYan){
		        		$(queren).addClass('register_active')
		        	}else{
		        		$(queren).removeClass('register_active')
		        	}
		        }else{
		        	if(isPhone && isPs){
		        		$(queren).addClass('register_active')
		        	}else{
		        		$(queren).removeClass('register_active')
		        	}
		        }
		    })
		}

		//验证码
    touch.on('#yanzhenNum','tap',function(){
      if(flag1){
        flag1=false;
        if($(this).hasClass('yanzhenNum')){
          num1=60;
          daojishi('#regPhone','#yanzhenNum',1);
          $.get(urls+'api/Register/SendPhoneCode',{
            Phone:$('#regPhone').val()
          },function(data){
            if(data.result == 1){
              $("#yanzhenNum").html("获取验证码").removeClass("yanzhenNum");

            }
          })

        }
      }
    })

    touch.on('#yanzhenNum2','tap',function(){
      if(flag2){
        flag2=false;
        if($(this).hasClass('yanzhenNum')){
          num2=60;
          daojishi('#resetPhone','#yanzhenNum2',2);
          $.get(urls+'api/Register/SendPhoneCodeByPwd',{
            Phone:$('#regPhone').val()
          },function(data){
            if(data.result == 1){
              $("#yanzhenNum2").html("获取验证码").removeClass("yanzhenNum");
            }
          })
        }
      }
    })

		function GetQueryString(name) {
			var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
			var r = window.location.search.substr(1).match(reg);
			if (r != null)return unescape(r[2]);
			return null;
		}

		var access_code = GetQueryString('code');
          if (access_code != null && access_code != "") {
            jQuery.get(urls+"api/User/LoginByWeChat?code=" + access_code, function(data) {
              if (data.result == 1) {//新用户
                var openid = data.msg;
                document.cookie = "openId=" + openid;
          touch.on('.qiangbao','tap',function(){
            $(".denlvbox").css('height',$(window).height()).show();
            $(".registerbox").show();
            $(".loginbox").hide();
            $(".resetbox").hide();
            $(".confirmBox").hide();
            formYan('#regPhone','#regPs','#registerBtn','#regYanzhen','#yanzhenNum')
          })

				}
				else if (data.result == 2) {//已注册的用户
					document.cookie = "Tonken=" + data.data.userToken;
					$.ajax({
            type:'get',
            url:urls+'/api/Order/GetIsBuyGood',
            headers: {
              Authorization: GetCookie('Tonken')
            },
            data:{goodId:1},
            success:function(data){
              if(data.result==1){//订单没有购买过
                //alert(1);
                $('.bannerbox').css('display','block');
                $('.houer4').css('display','block');
                $('#pfgg1').css('display','block');
              }else if(data.result==0){//订单创建完成，可以支付也可以不支付
                //alert(0);
                $('.bannerbox').css('display','none');
                $('.houer4').css('display','none');
                $('#pfgg1').css('display','none');
              }
              else if(data.result>1000){//没有相应权限即没有获取到token
                alert(data.msg);
              }
            }
          })
         /* jQuery.get(urls+'/api/Order/GetIsBuyGood',{
            goodId:1
          },function(data){
            if(data.result==1){
              alert(1);
              $('.bannerbox').css('display','none');
              $('.houer4').css('display','none');
              $('#pfgg1').css('display','none');
            }else{
              alert(2);
              $('.bannerbox').css('display','block');
              $('.houer4').css('display','block');
              $('#pfgg1').css('display','block');
            }
          })*/
					touch.on('.qiangbao','tap',function(){
            $(".denlvbox").css('height',$(window).height()).show();
            $(".registerbox").hide();
            $(".loginbox").hide();
            $(".resetbox").hide();
            /*$(".box_one").show();
            $(".box_two").hide();
            $(".box_three").hide();*/
            $(".confirmBox").show();
            $(".confirmBox").attr('goodsId',1);
            $(".confirmBox").attr('goodsName','4课时');
            $(".confirmBox").attr('price',99);
            $('.confirmCon h2:nth-child(1)').text('购买课程：4课时');
            $('.confirmCon h2:nth-child(2)').text('价格：¥99');
            //pay(1,'4课时套餐',99);
          })

          touch.on('#keshi1','tap',function(){
            $(".denlvbox").css('height',$(window).height()).show();
            $(".registerbox").hide();
            $(".loginbox").hide();
            $(".resetbox").hide();
            $(".confirmBox").show();
            $(".confirmBox").attr('goodsId',1);
            $(".confirmBox").attr('goodsName','4课时');
            $(".confirmBox").attr('price',99);
            $('.confirmCon h2:nth-child(1)').text('购买课程：4课时');
            $('.confirmCon h2:nth-child(2)').text('价格：¥99');
            //pay(1,'4课时套餐',99);
          })

          touch.on('#keshi2','tap',function(){
            $(".denlvbox").css('height',$(window).height()).show();
            $(".registerbox").hide();
            $(".loginbox").hide();
            $(".resetbox").hide();
            $(".confirmBox").show();
            $(".confirmBox").attr('goodsId',2);
            $(".confirmBox").attr('goodsName','30课时');
            $(".confirmBox").attr('price',998);
            $('.confirmCon h2:nth-child(1)').text('购买课程：30课时');
            $('.confirmCon h2:nth-child(2)').text('价格：¥998');
            //pay(2,'30课时套餐',998);
          })

          touch.on('#keshi3','tap',function(){
            $(".denlvbox").css('height',$(window).height()).show();
            $(".registerbox").hide();
            $(".loginbox").hide();
            $(".resetbox").hide();
            $(".confirmBox").show();
            $(".confirmBox").attr('goodsId',3);
            $(".confirmBox").attr('goodsName','60课时');
            $(".confirmBox").attr('price',1688);
            $('.confirmCon h2:nth-child(1)').text('购买课程：60课时');
            $('.confirmCon h2:nth-child(2)').text('价格：¥1688');
            //pay(3,'60课时套餐',1688);
          })

          touch.on('#pfqb','tap',function(){
            $(".denlvbox").css('height',$(window).height()).show();
            $(".registerbox").hide();
            $(".loginbox").hide();
            $(".resetbox").hide();
            $(".confirmBox").show();
            $(".confirmBox").attr('goodsId',1);
            $(".confirmBox").attr('goodsName','4课时');
            $(".confirmBox").attr('price',99);
            $('.confirmCon h2:nth-child(1)').text('购买课程：4课时');
            $('.confirmCon h2:nth-child(2)').text('价格：¥99');
            //pay(1,'4课时套餐',99);
          })

				}else if(data.result>=1000){//Tonken过期
          alert(data.result);
					document.cookie = "Tonken="+'';
					window.location.reload();
				}else if(data.result == 0){
				  // alert(1);
				  location.href = location.href.split('?')[0];
        }
			})
		} else {
			var curUrl = location.href;
			var url = "https://open.weixin.qq.com/connect/oauth2/authorize";
			url += "?appid=wxcd96ac91c795045f&redirect_uri=" + encodeURIComponent(curUrl) + "&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect";
			location.href = url;
		}
		//注册
    touch.on('#registerBtn','tap',function(){
      $.get(urls+'api/Register/UserRegister',{
        Phone:$('#regPhone').val(),
        Code:$('#regYanzhen').val(),
        OpenId:GetCookie('openId'),
        Password:$('#regPs').val()
      },function(data){
        if(data.result==2){
          $(".registerbox").hide();
          $(".confirmBox").show();
          document.cookie = "Tonken=" + data.data.userToken;
        }else{
          alert(data.msg);
        }
      })
    })

		//登录
    touch.on('#loginBtn','tap',function(){
      $.post(urls+'api/Register/Login',{
        UserName:$('#logPhone').val(),
        Password:$('#logPs').val()
      },function(data){
        if(data.result==2){
          $(".loginbox").hide();
          $(".confirmBox").show();//确认订单显示
        }else{
          alert(data.msg);
        }
      })
    })

    //重置密码
    touch.on('#resetBtn','tap',function(){
      $.post(urls+'api/Register/ChangePwdByPoneCode',{
        Phone: $('#resetPhone').val(),
        Code: $('#resetYan').val(),
        NewPsw: $('#resetPs').val(),
        ConfirmPsw:  $('#resetPs').val()
      },function(data){
        if(data.result==2){
          $('.resetbox').hide();
          $('.loginbox').show();
        }else{
          alert(data.msg);
        }
      })
    })

    //确认支付
    //确认支付点击事件绑定的函数
    var appId="";
    var timeStamp="";
    var nonceStr="";
    var package="";
    var signType="";
    var paySign="";
    var goodId="";
    function onBridgeReady(){
      // var dataObj=JSON.parse('{ "appId" : "'+appId+'","timeStamp" : "'+timeStamp+'","nonceStr" : "'+nonceStr+'","package" : "'
      //   +package+'","signType" : "'+signType+'","paySign" :  "'+paySign+'"}');
      var dataObj=JSON.parse('{ "appId" : "'+appId+'","timeStamp" : "'+timeStamp+'","nonceStr" : "'+nonceStr+'","package" : "'
        +package+'","signType" : "'+signType+'","paySign" :  "'+paySign+'","goodId":"'+goodId+'"}');
      WeixinJSBridge.invoke('getBrandWCPayRequest',dataObj , function(res) {

        if (res.err_msg == "get_brand_wcpay_request:ok") {//调取微信支付接口成功
          alert('success');
          // location.href="http://wx.gogo-talk.com/h5test/h5index/code.html";
          location.href=location.href.split('index.html')[0]+'code.html';
          //alert(2);
          if(goodId==1){
            $('.bannerbox').css('display','none');
            $('.houer4').css('display','none');
            $('#pfgg1').css('display','none');
          }
          //location.href=location.href.split('/h5index')[0] + location.href.split('/h5index')[1]   + "#/My_order";//调到我的订单列表页面
        } // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。
        else {//调取微信接口失败，返回首页，重新去购买
          // alert(res.msg);
          //alert(3);
          $('.denlvbox').hide();
          //location.href=location.href.split('?')[0];
          // location.href=location.href+"#/My_order";
        }
      });
    }

    function callPay(){
      if (typeof WeixinJSBridge == "undefined"){
        if( document.addEventListener ){
          document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
        }else if (document.attachEvent){
          document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
          document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
      }else{
        onBridgeReady();
      }
    }

    touch.on('.payBtn','tap',function(){
      //var urlObj =
      //console.log(urlObj);
      var goodsId=$('.confirmBox').attr('goodsId');
      var goodsName=$('.confirmBox').attr('goodsName');
      var price=$('.confirmBox').attr('price');
      // alert(goodsId+""+goodsName+price+"");
      var postUrl = urls+'api/Order/PostZhiFu';
      //微信
      jQuery.ajax({
        url: postUrl,
        headers: {
          Authorization: GetCookie('Tonken')
        },
        type: "post",
        data: {
          ZhiFuType :2,
          OrderNum :"",
          GoodsId :goodsId,
          GoodsName :goodsName,
          GPrice:price,
          Remarks:"",
          CouponId :0,
          PaySource :1
        },
        success: function (data) {

          if (data.result == 1) {//调取微信接口
            alert('调取微信接口');
            appId= data.data.appId;
            timeStamp=data.data.timeStamp;
            nonceStr = data.data.nonceStr;
            package = data.data.package;
            signType = data.data.signType;
            paySign=  data.data.paySign;
            goodId=goodsId;
            callPay();
          } else if (data.result >= 1000) {//Token过期后，重新获取Token
            // alert(data.result);
            document.cookie = "Tonken=" + '';
            window.location.reload();
          } else {//data.result==0 订单生成，但没有支付
            //location.href=location.href.split('/h5index')[0] + "#/My_order";
            alert(data.msg);
          }
        }
      });
    })


    //苹果微信端的返回按钮
    pushHistory();
    function pushHistory(){
      window.addEventListener("popstate", function(e){
        // location.href = 'http://wx.gogo-talk.com/h5test/index.html';
        //window.history.back();
        //在历史记录中后退,这就像用户点击浏览器的后退按钮一样。

        //window.history.go(-1);
        //你可以使用go()方法从当前会话的历史记录中加载页面（当前页面位置索引值为0，上一页就是-1，下一页为1）。

        //self.location=document.referrer;
        //可以获取前一页面的URL地址的方法,并返回上一页。
      }, false);
      var state = {
        title:"",
        url: "#"
      };
      window.history.pushState(state, "", "#");
    };

    //兼容安卓手机表单被键盘遮盖
    windowInnerHeight
      = window.innerHeight; //获取当前浏览器窗口高度

    $(window).resize(function(){
      if(window.innerHeight < windowInnerHeight){
        //alert(1);
        $('.denlvbox').css('position','static');//也可以在css文件夹写个类名，然后相对应的removeClass和addClass既可

      }else{
        //alert(2);
        $('.denlvbox').css('position','fixed');

      }
    });

